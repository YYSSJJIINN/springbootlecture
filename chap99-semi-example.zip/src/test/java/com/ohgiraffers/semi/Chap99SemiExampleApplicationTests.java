package com.ohgiraffers.semi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap99SemiExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
